package com.annatsar.insertdata

class Users (var NIM : String, var nama: String, var jurusan:String, var universitas:String) {

    constructor() : this("", "","", "") {

    }
}